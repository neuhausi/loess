#ifndef DLOESS_MISC_H_
#define DLOESS_MISC_H_

void
Recover(char *a, int *b);

void
Warning(char *a, int *b);

#endif // DLOESS_MISC_H_
