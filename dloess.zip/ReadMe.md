This repository contain minimal modifications of http://www.netlib.org/a/dloess "Software for Locally-Weighted Regression"
for compiling on x64 platforms.

Author: Alexander Rudalev, Northern (Arctic) Federal University

